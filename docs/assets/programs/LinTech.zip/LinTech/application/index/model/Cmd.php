<?php
namespace app\index\model;

use think\Model;

class Cmd extends Model
{

    // 设置完整的数据表（包含前缀）
    protected $table = 'dev_cmd';

    // 关闭自动写入时间戳
    protected $autoWriteTimestamp = true;

    //默认时间格式
    // protected $dateFormat = 'Y-m-d H:i:s';

    //自动完成
    protected $insert = [
        // 'create_time'
    ];


    // status属性读取器
    protected function getStatusAttr($value)
    {
        $status = [1=>'等待处理',2=>'等待回执',3=>'回执成功',4=>'回执错误',5=>'重试失败',6=>'类型错误',null=>'初始化'];
        return $status[$value];
    }

    protected function getTypeAttr($value)
    {   
        if($value == 1)
        {
            return 'BMS通讯';
        }elseif($value == 2){
            return '参数设置';
        }else{
            return '类型错误';
        }
    }

}