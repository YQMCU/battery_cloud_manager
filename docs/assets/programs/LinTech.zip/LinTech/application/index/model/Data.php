<?php
namespace app\index\model;

use think\Model;

class Data extends Model
{

    // 设置完整的数据表（包含前缀）
    protected $table = 'dev_data';

    // 关闭自动写入时间戳
    //protected $autoWriteTimestamp = false;

    //默认时间格式
    protected $dateFormat = 'Y-m-d H:i:s';

    protected $type       = [
        // 设置时间戳类型（整型）
        // 'create_time'     => 'timestamp',
        // 'update_time'     => 'timestamp',
    ];

    //自动完成
    protected $insert = [
        'update_time'
    ];



    // status属性读取器
    protected function getStatusAttr($value,$data)
    {
        // return $status[$value];
        if(time() > strtotime($data['update_time'])+600) //600秒 10min
        {
            return "离线";
        }
        else
        {
            return "在线";
        }
    }

    // 获取当前位置
    protected function getLocAttr($value,$data)
    {
        return $data['lng'].','.$data['lat'];
    }

    // gps类型读取
    protected function getGpsAttr($value)
    {
        return ($value == 0) ? "基站定位" : "GPS定位";
    }

}