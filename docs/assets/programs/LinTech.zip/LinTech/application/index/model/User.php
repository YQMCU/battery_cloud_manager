<?php
namespace app\index\model;

use think\Model;

class User extends Model
{

    // 设置完整的数据表（包含前缀）
    protected $table = 'user_info';

    // 关闭自动写入时间戳
    protected $autoWriteTimestamp = false;

    //默认时间格式
    protected $dateFormat = 'Y-m-d H:i:s';

    protected $type       = [
        // 设置时间戳类型（整型）
        'create_time'     => 'timestamp',
        'update_time'     => 'timestamp',
        'last_login_time' => 'timestamp',
        'expire_time' => 'timestamp',

    ];

    //自动完成
    protected $insert = [
    	'update_time'
    ];

    // protected $update = ['update_time'];

    // 属性修改器

     protected function getCreateTimeAttr($datetime)
    {
        return date('Y-m-d H:i:s', $datetime);
    }

    // 属性修改器
    protected function setUpdateTimeAttr($value, $data)
    {
        return time();
    }

     protected function getUpdateTimeAttr($datetime)
    {
        return date('Y-m-d H:i:s', $datetime);
    }


    protected function getLastLoginTimeAttr($datetime)
    {
        return date('Y-m-d H:i:s', $datetime);
    }


    protected function getExpireTimeAttr($datetime)
    {
        return date('Y-m-d H:i:s', $datetime);
    }

    // status属性读取器
    protected function getRoleAttr($value)
    {
        $role = [1 => '经销商', 2 => '管理员', 3 => '用户', 4 => '待审核', 5 => '黑名单'];
        return $role[$value];
    }

}