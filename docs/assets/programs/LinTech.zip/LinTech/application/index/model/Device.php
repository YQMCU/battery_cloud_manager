<?php
namespace app\index\model;

use think\Model;

class Device extends Model
{

    // 设置完整的数据表（包含前缀）
    protected $table = 'dev_info';

    // 关闭自动写入时间戳
    //protected $autoWriteTimestamp = false;

    //默认时间格式
    protected $dateFormat = 'Y-m-d H:i:s';

    protected $type       = [
        // 设置时间戳类型（整型）
        // 'create_time'     => 'timestamp',
        // 'update_time'     => 'timestamp',
    ];

    //自动完成
    protected $insert = [
        'update_time'
    ];

    // protected $update = ['update_time'];

    protected function setUpdateTimeAttr($value, $data)
    {
        return 'time()';
    }


    protected function getHeartTAttr($value)
    {
        return $value/1000..'秒';
    }

    protected function getRepoTAttr($value)
    {
        return $value/1000..'秒';
    }

    protected function getBmsTAttr($value)
    {
        return $value/1000..'秒';
    }

    protected function getGpsTAttr($value)
    {
        return $value/1000..'秒';
    }

    protected function getGpsEnableAttr($value)
    {
        return ($value == 0) ? "开启" : "关闭";
    }

    // gps类型读取
    protected function getBmsEnableAttr($value)
    {
        return ($value == 0) ? "开启" : "关闭";
    }

}