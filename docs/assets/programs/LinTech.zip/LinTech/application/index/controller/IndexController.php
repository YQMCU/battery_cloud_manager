<?php
namespace app\index\controller;

use think\Controller;
use think\Db;
use app\index\model\User;
use think\Validate;
use app\index\controller\AdminAuth;

// use app\admin\controller\AdminAuth;

class IndexController extends AdminAuth
{
    public function index()
    {
        return $this->fetch();
    }

    public function login()
    {
        // dump(session("admin_role"));
        if(session("admin_username") && session("admin_password"))
        {
            if(session('admin_role') == "普通用户")
            {
                $this->success('欢迎回来','/home');
            }
            else if(session('admin_role') == "管理员")
            {
                $this->success('欢迎回来','/admin');
            }
        }

        $this->view->engine->layout(false);
        return view();
    }

    public function register()
    {
        $data = input('post.');
        $rule = [
            'reg_username|帐号' => 'require|min:5|chsDash',
            'reg_password|密码' => 'require|min:5|chsDash',
            'reg_device_id|电池铭牌编号' => 'chsDash'
            // 'reg_mobile|手机号' => 'mobile'
        ];
        // 数据验证
        $validate = new Validate($rule);
        $result   = $validate->check($data);
        if(!$result){
            return $validate->getError();
        }
        // 初始化数据模型
        $user = new User;
        $check = $user->where('username',$data['reg_username'])->find();
        if(!$check){
            // 没有重名
            $salt = config('password_salt');
            $raw = $data['reg_password'];
            $password = md5($salt.$data['reg_password'].$salt);
            $user->username = $data['reg_username'];
            $user->role = '1';// 普通用户
            $user->raw = $raw;
            $user->password = $password;
            $user->mobile = (!$data['reg_mobile']) ? "" : $data['reg_mobile'];
            $user->address = (!$data['reg_address']) ? "" : $data['reg_address'];
            $user->wx = (!$data['reg_wx']) ? "" : $data['reg_wx'];
            $user->create_time = time();
            $user->save();
            $this->success("注册成功",'/login');
        }else{
            $this->error("用户名已存在",'/login');
        }
    }    

    public function login_action()
    {
        $user = new User; /*使用用户表*/
        $data = input('post.');
        $rule = [
            'admin_username|帐号' => 'require|min:5|chsDash',
            'admin_password|密码' => 'require|min:5|chsDash'
        ];
        // 数据验证
        $validate = new Validate($rule);
        $result   = $validate->check($data);
        if(!$result){
            return $validate->getError();
        }
        
        $check1 = $user->where(array('username'=>$data['admin_username'],'role'=>1))->find();
        $check2 = $user->where(array('username'=>$data['admin_username'],'role'=>2))->find();
        
        if(!$check1 and !$check2)
        {
            $this->error('用户不存在','/login#signup');
        }

        if($check1 and $check2)
        {
            $this->error("有重名");
        }

        $salt = config('password_salt');
        $where_query = array(
                'username' => $data['admin_username'],
                /*密码加盐 有盐并且盐不是空 */
                'password' => md5($salt.$data['admin_password'].$salt)
            );

        if ($user = $user->where($where_query)->find()) {
            /*注册session*/
            session('uid',$user->id);
            session('admin_username',$user->username);
            session('admin_password',$user->password);
            session('admin_role',$user->role);
            // session('admin_nickname',$user->nickname);

            /*更新最后请求IP及时间*/
            $request = request();
            $ip = $request->ip();
            $time = time();
            $expire_time = time()+config('auth_expired_time');
            $user->where($where_query)->update(['last_login_ip' => $ip, 'last_login_time' => $time,'expire_time'=>$expire_time]);

            if($user->role == '普通用户')
            {
                $this->success('登录成功', '/home');
            }
            else if($user->role == '管理员')
            {
                $this->success("登录成功",'/admin');
            }
        } else {
            $this->error('登录失败:账号或密码错误');
        }
    }

    public function logout()
    {
        session(null);

        $this->error('退出成功','/login');
    }

    public function hello()
    {
        return $this->fetch();
    }

    public function test()
    {
        return $this->fetch();
    }

}
