<?php
namespace app\dev\controller;
use think\Controller;
use app\index\model\Cmd;
use app\index\model\Data;
// use think\Request;
use think\Db;


class IndexController extends Controller
{
    public function test()
    {
    	$cmd = Db::table('dev_cmd');
    	$list_cmd = $cmd->order('update_time','desc')->select();
    	$this->assign('list_cmd',$list_cmd);


        $this->assign('list_data',Data::order('update_time','desc')->paginate(10));
        // dump()
        return $this->fetch();

    }


    public function insert($table_name)
    {
    	$data =  input('post.');
    	// return $data;
    	// $cmd = new Cmd;
    	$cmd = Db::table($table_name);
    	$cmd->insert($data);
        return $data;
    }

    public function delete($table_name)
    {
    	$data = input('post.');
    	$cmd = new Cmd;
    	$cmd->order('id','desc')->limit(1)->find()->delete();

    }

    public function show()
    {
        $data = array(
            array("id"=>"1","name"=>"name1"),
            array("id"=>"2","name"=>"name2"),
            array("id"=>"2","name"=>"name2"),
            array("id"=>"3","name"=>"name3"),
            array("id"=>"4","name"=>"name4"),
            array("id"=>"5","name"=>"name5"),
            array("id"=>"6","name"=>"name6"),
            );
        $data->paginate(1);
        // dump($data);
    }

    public function p($cb=NULL)
    {
        if($cb)
        {
            $this->$cb(); 
        }
    }

    public function cb()
    {
        dump('callback');
    }

    // map
    public function index()
    {
        return $this->fetch();
    }

    public function lbs()
    {
        $data = input('post.'); //获取来自iot.openluat.com转发的数据
        if($data)
        {
           Db::execute('insert into dev_data (lbs) values (?)',[implode('',$data)]);
        }
    }

    public function testlbs()
    {
        return $this->fetch('index/lbs');
    }

    public function sim()
    {
        $ch = curl_init();
        $user = "3TbXyG8ocNrGMTou";
        $pass = "6GBkF3wp0sT37h74UXr3jKNJXKqM4PJxutVb0k2Qx8POdzTCIujT0xyoesnKJXwd";
        curl_setopt($ch, CURLOPT_URL, "http://www.openluat.com/");  
        curl_setopt($ch, CURLOPT_PORT, 80);   
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);  
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);   
        curl_setopt($ch, CURLOPT_HEADER, 1);  
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);  
        // curl_setopt($ch, CURLOPT_USERPWD, "{$user}:{$pass}");  
        // curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);  
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);  
          
        $return = curl_exec($ch);  
        if (!$return) {  
            echo curl_error($ch);  
        }  
        else {  
            echo $return;  
        }  
        curl_close($ch);  

    }
}
