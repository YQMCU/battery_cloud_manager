<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

return [
     // 全局变量规则定义
    '__pattern__'         => [
        'name'  => '\w+',
        'id'    => '\d+',
        'year'  => '\d{4}',
        'month' => '\d{2}',
    ],

    // 'test/'                                       => 'admin/test'
    'login$' => 'index/index/login',//登陆
    // 'register' => 'index/index/login#signup',
    // 'lost_password' => 'index/index/'
    'logout$' => 'index/index/logout',
    'home$' => 'index/index/index',
    'admin$' => 'admin/admin/index',//后台首页
    'admin/list$' => 'admin/admin/admin_list',//管理员列表
    'admin/add$' => 'admin/admin/add',
    'user/list$' => 'admin/admin/user_list',//用户列表
    'user/add$' => 'admin/admin/user_add',//添加用户
    'device/list$' => 'admin/device/info',//设备列表
    'complete$' => 'admin/user/complete',
    'data$' => 'admin/device/data',
    'list$' => 'admin/device/info',
    'serial_num$' => 'admin/device/bind',
    'owner$' => 'admin/device/owner',
    'para$' => 'admin/device/para',
    'state$' => 'admin/device/state',
    'site$' => 'admin/device/site',
    // 'states/data1$' => 'admin/device/history_state/id/data1',
    // 'states/:id' => 'admin/device/history_state',
    // 'states/:id/:num$' => 'admin/device/history_state',
    'history/location$' => 'admin/device/history_location',
    'setting$' => 'admin/system/setting',
    'bms/command$' => 'admin/system/ctrl'
];
