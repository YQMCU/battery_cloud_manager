<?php
namespace app\admin\controller;
use app\index\model\User;
use app\index\model\Data as Device;
use app\index\model\Device as DeviceReset;
use app\index\controller\AdminAuth;
use app\admin\controller\AdminCheck;
use think\Validate;
// use think\Image;
use think\Request;
use think\Controller;


class AdminController extends AdminAuth
{

	/**
	 * 后台管理主页
	 * @return [type] [description]
	 */
	public function index()
	{
    $this->data['user_count'] = User::where('role',1)->count();
    $this->data['admin_count'] = User::where('role',2)->count();
    $this->data['device_count'] = Device::count('DISTINCT imei');		

		$this->assign('data',$this->data);

		return $this->fetch();
	}

	/**
	 * 管理员列表
	 * @return [type] [description]
	 */
	public function admin_list()
	{	
		$list = User::where('role',2)->select();
		$this->assign('list',$list);//表内容
		return $this->fetch('admin/list');
	}

	/**
	 * 用户列表
	 * @return [type] [description]
	 */
	public function user_list()
	{
		$list2 = User::where('role',1)->select();
		$this->assign('list',$list2);
		return $this->fetch('user/list');
	}

	public function user_add()
	{
		return $this->fetch('user/add');
	}

	public function user_add_action()
	{
		$data = input('post.');
    $rule = [
        'name|帐号' => 'require|min:5|chsDash',
        'password|密码' => 'require|min:5|chsDash',
        'serial|电池铭牌编号' => 'chsDash'
        // 'reg_mobile|手机号' => 'mobile'
    ];
    // 数据验证
    $validate = new Validate($rule);
    $result   = $validate->check($data);
    if(!$result){
        return $validate->getError();
    }
    // 初始化数据模型
    $user = new User;
    $check = $user->where('username',$data['name'])->find();
    if(!$check){
        // 没有重名
        $salt = config('password_salt');
        $raw = $data['password'];
        $password = md5($salt.$data['password'].$salt);
        $user->username = $data['name'];
        $user->role = $data['role'] == 'admin' ? 2 : 1;// 普通用户
        $user->raw = $raw;
        $user->password = $password;
        $user->mobile = (!$data['mobile']) ? "" : $data['mobile'];
        $user->address = (!$data['address']) ? "" : $data['address'];
        $user->wx = (!$data['wx']) ? "" : $data['wx'];
        $user->save();
        return $this->success("添加成功",'/user/add');
    }else{
        return $this->error("用户名已存在",'/user/add');
    }
	}

	public function datalist()
	{
    $D = new User;
    $list = $D->paginate(10);
    // $this->assign('data',$this->data);
    $this->assign('list',$list); //表内容
		return $this->fetch('admin/user_list');
	}

}