<?php 
namespace app\admin\controller;

use app\index\controller\AdminAuth; // 权限验证
use app\index\model\Device; // 设备
use app\index\model\User; // 设备

class ListController extends AdminAuth
{
	// 账户管理
	public function user()
	{
		$list_user = User::order('username','asc')->where('role','1')->select(); // 经销商
		$list_admin = User::order('username','asc')->where('role','2')->select(); // 管理员
		$this->assign('list_user',$list_user);
		$this->assign('list_admin',$list_admin);
		return $this->fetch();
	}

	// 设备管理 
	public function dev()
	{
		$list_dev = Device::order('imei','asc')->select(); // 设备
		$this->assign('list_dev',$list_dev);
		return $this->fetch();
	}




}