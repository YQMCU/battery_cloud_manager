<?php 
namespace app\admin\controller;
use app\index\controller\AdminAuth;
use think\Request;
use think\Controller;


class AdminCheck extends AdminAuth
{
	protected function _initialize()
	{
		
		if(session('admin_role') == '管理员')
		{

		}elseif(session('admin_role') == '普通用户')
		{
			return $this->error('很抱歉，没有操作权限','/home');
		}
	}
}