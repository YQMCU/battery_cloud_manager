<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件

use think\Db;

/**
 * This function adds once the CKEditor's config vars
 * @author Samuel Sanchez
 * @access private
 * @param array $data (default: array())
 * @return string
 */
function cke_initialize($data = array()) {

	$return = '';

	if(!defined('CI_CKEDITOR_HELPER_LOADED')) {
		if (!isset($data['path'])) $data['path'] = '/static/editor/ckeditor/';
		define('CI_CKEDITOR_HELPER_LOADED', TRUE);
		$return =  '<script type="text/javascript" src="'.$data['path'] . 'ckeditor.js"></script>';
		$return .=  '<script type="text/javascript" src="/static/editor/ckfinder/ckfinder.js"></script>';
		$return .=	"<script type=\"text/javascript\">CKEDITOR_BASEPATH = '" . $data['path'] . "';</script>";
	}

	return $return;

}

/**
 * This function create JavaScript instances of CKEditor
 * @author Samuel Sanchez
 * @access private
 * @param array $data (default: array())
 * @return string
 */
function cke_create_instance($data = array()) {

    $return = "<script type=\"text/javascript\">
     	var editor = CKEDITOR.replace('" . $data['id'] . "', {";

    		if(!isset($data['config']['width'])) $data['config']['width'] = '600';
			if(!isset($data['config']['height'])) $data['config']['height'] = '600';

    		//Adding config values
    		if(isset($data['config'])) {


	    		foreach($data['config'] as $k=>$v) {

	    			// Support for extra config parameters
	    			if (is_array($v)) {
	    				$return .= $k . " : [";
	    				$return .= config_data($v);
	    				$return .= "]";

	    			}
	    			else {
	    				$return .= $k . " : '" . $v . "'";
	    			}

	    			if(array_key_exists($k,$data['config'])) {
						$return .= ",";
					}
	    		}
    		}

    $return .= '}); CKFinder.setupCKEditor( editor, "__PUBLIC__/editor/ckfinder/" );</script>';

    return $return;

}

/**
 * This function displays an instance of CKEditor inside a view
 * @author Samuel Sanchez
 * @access public
 * @param array $data (default: array())
 * @return string
 */
function display_ckeditor($data = array())
{
	// Initialization
	$return = cke_initialize($data);

    // Creating a Ckeditor instance
    $return .= cke_create_instance($data);


    // Adding styles values
    if(isset($data['styles'])) {

    	$return .= "<script type=\"text/javascript\">CKEDITOR.addStylesSet( 'my_styles_" . $data['id'] . "', [";


	    foreach($data['styles'] as $k=>$v) {

	    	$return .= "{ name : '" . $k . "', element : '" . $v['element'] . "', styles : { ";

	    	if(isset($v['styles'])) {
	    		foreach($v['styles'] as $k2=>$v2) {

	    			$return .= "'" . $k2 . "' : '" . $v2 . "'";

					if($k2 !== end(array_keys($v['styles']))) {
						 $return .= ",";
					}
	    		}
    		}

	    	$return .= '} }';

	    	if($k !== end(array_keys($data['styles']))) {
				$return .= ',';
			}


	    }

	    $return .= ']);';

		$return .= "CKEDITOR.instances['" . $data['id'] . "'].config.stylesCombo_stylesSet = 'my_styles_" . $data['id'] . "';
		</script>";
    }

    return $return;
}

/**
 * config_data function.
 * This function look for extra config data
 *
 * @author ronan
 * @link http://kromack.com/developpement-php/codeigniter/ckeditor-helper-for-codeigniter/comment-page-5/#comment-545
 * @access public
 * @param array $data. (default: array())
 * @return String
 */
function config_data($data = array())
{
	$return = '';
	foreach ($data as $k => $key)
	{
		if (is_array($key)) {
			$return .= "[";
			foreach ($key as $k2 => $string) {
				$return .= "'" . $string . "'";
				if(array_key_exists($k2,$key)) $return .= ",";
			}
			$return .= "]";
		}
		else {
			$return .= "'".$key."'";
		}
		if(array_key_exists($k,$key)) $return .= ",";

	}
	return $return;
}

//     
/**
 * 将获取到的bms的数据集内容进行解析
 * bms的寄存器信息在config.php
 * @param  [数组] $lists [取得的原始数据的集合]
 * @param  [字符串] $id    [需要获取的数据名] data1~data10
 */
function convert_bms_datas($lists,$id)
{
    $data = config('bms')[$id];
    $title = $data['title'];//数据标题
    $head = $data['repo_head'];//数据头
    $details = $data['detail'];//数据详情
    $len = $data['len'];//数据长度
    // $D = new Device;
    // $lists = $D->where($id,'<>','')->limit($num)->select();
    // dump($lists);
    $raw_datas = array();//最终返回的数组数据
    $i = 0;//索引
    // dump($lists);
    foreach ($lists as $list) {
        // 校验数据
        $raw = $list[$id];
        $time = $list['update_time'];
        $imei = $list['imei'];
        // $serial_num = $list['serial_num'];
        // 获取序列号
        // $d = Db::table('dev_data')->where('imei',$imei)->find();
        $dd = Db::table('dev_info')->where('imei',$imei)->find();
        // dump($dd);
        // dump($imei);
        $serial_num = $dd['serial_num'];
        // $serial_num = $dd->serial_num;
        // if($d['serial_num']){
        //     $serial_num = $d['serial_num'];
        // }else{
        //     $serial_num = '';
        // }
        // dump($raw);
        // echo $time;
        if(preg_match('/^'.$head.'/i',$raw) and $len == strlen($raw))//and strlen($raw) == $len) // 匹配数据头 和 数据长度
        {
            $raw_datas[$i]['raw'] = $raw;//原始数据存入数组
            $raw_datas[$i]['time'] = $time;//数据时间存入数组
            $raw_datas[$i]['serial_num'] = $serial_num;//设备号存入数组
            $raw_datas[$i]['imei'] = $imei;//序列号存入数组
            $raw_datas[$i]['detail'] = array();
            // $raw = preg_replace('/^'.$head.'/i',$raw,'');
            // dump($raw);
            $raw_data = substr($raw,strlen($head),strlen($raw)-strlen($head));
            // dump($raw);
            for($j=0;$j<strlen($raw_data)/4-1;$j++)
            {
                $start = $j*4;
                $raw_str = substr($raw_data,$start,4);
                // dump(strlen($raw_data)/4-1);
                $lev = $details[$j]['lev'];//精度
                if($lev != 'bit')
                {
	                $raw_datas[$i]['detail'][$j]['value'] = hexdec($raw_str)/pow(10,$lev);//值
                }
                else{
					$raw_datas[$i]['detail'][$j]['value'] = $raw_str;                	
                }
                $raw_datas[$i]['detail'][$j]['name'] = $details[$j]['name'];//项目名称
            } 
        }
        $i++;
    }
    // dump($raw_datas);
    return $raw_datas;//返回解析后的数据
}